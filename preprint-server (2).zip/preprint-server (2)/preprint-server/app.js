const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const multer = require('multer');
const path = require('path');
const User = require('.\\models\\User.js'); // Corrected path using backslashes

const bcrypt = require('bcrypt');

const session = require('express-session');



const app = express();
app.use(session({
    secret: 'your_secret_key',
    resave: false,
    saveUninitialized: true
}));
// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/preprintdb', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('Error connecting to MongoDB:', err));

// Set up EJS as the templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Serve static files from the "uploads" folder
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));


// Ensure the uploads directory exists
const fs = require('fs');
const uploadDir = path.join(__dirname, 'public', 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer configuration for file uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir); // Save uploaded files to the 'public/uploads/' directory
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + '-' + file.originalname); // Use a unique filename
    }
});

const upload = multer({ storage: storage });

// Import the Preprint model
const Preprint = require('./models/Preprint');

// Routes
app.get('/', async (req, res) => {
    try {
        const searchQuery = req.query.search || '';  // Get search query from query string
        console.log('Search Query:', searchQuery);  // Log search query for debugging

        let preprints = await Preprint.find();  // Fetch all preprints initially
        let message = '';

        if (searchQuery) {
            // Filter preprints based on search query (case-insensitive)
            preprints = preprints.filter(preprint => 
                new RegExp(searchQuery, 'i').test(preprint.title)
            );

            if (preprints.length === 0) {
                message = 'No records found for the search query.';
            }
        }

        console.log('Final Displayed Preprints:', preprints);  // Log search results for debugging
        
        // Render the 'index' view with search results
        res.render('index', { preprints, searchQuery, message });
    } catch (err) {
        console.error('Error fetching preprints:', err);
        res.status(500).send('Internal Server Error');
    }
});


app.get('/preprint/:id', async (req, res) => {
    try {
        const preprint = await Preprint.findById(req.params.id);
        if (!preprint) {
            return res.status(404).send('Preprint not found');
        }

        res.render('preprint', { preprint });
    } catch (err) {
        console.error('Error fetching preprint:', err);
        res.status(500).send('Internal Server Error');
    }
});


app.get('/submit', (req, res) => {
    res.render('submit');
});
app.get('/about', (req, res) => {
    console.log("About page requested");  // Debug log
    res.render('about');
});
app.get("/team", (req, res) => {
    res.render("team");
});

app.get('/latestpreprints', async (req, res) => {
    try {
        const searchQuery = req.query.search || '';  // Get the search query from query string
        let preprints = await Preprint.find();  // Fetch all preprints initially
        let message = '';

        if (searchQuery) {
            // Filter preprints based on search query (case-insensitive)
            preprints = preprints.filter(preprint => 
                new RegExp(searchQuery, 'i').test(preprint.title)
            );

            if (preprints.length === 0) {
                message = 'No records found for the search query.';
            }
        }

        res.render('latestpreprints', { preprints, searchQuery, message });
    } catch (err) {
        console.error('Error fetching preprints:', err);
        res.status(500).send('Internal Server Error');
    }
});

function generateDOI() {
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';

    let alphaPart = '';
    let numPart = '';

    // Generate 6 random letters
    for (let i = 0; i < 6; i++) {
        alphaPart += letters.charAt(Math.floor(Math.random() * letters.length));
    }

    // Generate 6 random numbers
    for (let i = 0; i < 6; i++) {
        numPart += numbers.charAt(Math.floor(Math.random() * numbers.length));
    }

    return `10.1234/${alphaPart}${numPart}`;

}


// Function to extract references dynamically
function extractReferences(text) {
    const match = text.match(/(References|Bibliography)[\s\S]+/i);
    if (!match) return [];

    const referenceText = match[0];
    const lines = referenceText.split("\n").filter(line => line.trim().length > 5);

    let references = [];
    lines.forEach(line => {
        // Match both DOI and full URLs
        const linkMatch = line.match(/(https?:\/\/[^\s]+|\b10\.\d{4,9}\/[-._;()/:A-Za-z0-9]+)/);
        const titleMatch = line.match(/^(.*?)(https?:\/\/[^\s]+|\b10\.\d{4,9}\/[-._;()/:A-Za-z0-9]+)/);

        if (titleMatch && linkMatch) {
            let link = linkMatch[0];

            // Convert DOI to a full URL if it's not already
            if (link.startsWith("10.")) {
                link = `https://doi.org/${link}`;
            }

            references.push({
                title: titleMatch[1].trim(), // Extract full title before the link
                link: link
            });
        }
    });

    console.log("Extracted References:", references);
    return references;
}


const pdfParse = require('pdf-parse');

app.post('/submit', upload.single('pdf'), async (req, res) => {
    try {
        const { title, author, abstract } = req.body;
        const pdfPath = req.file ? `./public/uploads/${req.file.filename}` : null;

        if (!pdfPath) {
            return res.status(400).send("No PDF uploaded.");
        }

        // Read and extract text from PDF
        const dataBuffer = fs.readFileSync(pdfPath);
        const data = await pdfParse(dataBuffer);
        const pdfText = data.text;

        // Extract references from the PDF text
        const references = extractReferences(pdfText);

        // Generate DOI
        const doi = generateDOI();
        console.log("Generated DOI:", doi);  // Debug log

        // Create a new preprint document
        const newPreprint = new Preprint({
            title,
            author,
            abstract,
            pdf: req.file ? `/uploads/${req.file.filename}` : '',
            references,
            doi
        });

        await newPreprint.save();
        console.log("Preprint saved successfully with DOI:", doi);

        res.redirect('/');
    } catch (err) {
        console.error('Error processing PDF:', err);
        res.status(500).send('Internal Server Error');
    }
});

app.get("/signup", (req, res) => res.render("signup"));
app.get("/login", (req, res) => res.render("login"));


// app.get("/submit",  (req, res) => res.render("submit"));


app.post("/signup", async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.send("All fields are required");
    }
  
    try {
      const existingUser = await User.findOne({ email });
      if (existingUser) {
        return res.send("User already exists. Please login.");
      }
  
      const hashedPassword = await bcrypt.hash(password, 10);
      const user = await User.create({ name, email, password: hashedPassword });
  
      req.session.userId = user._id;
      req.session.user = user;
      res.redirect("/login");
    } catch (error) {
      console.error(error);
      res.send("Error signing up. Please try again.");
    }
  });
  
  // Login Route
  app.post("/login", async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).send("Invalid email or password");
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).send("Invalid email or password");
        }

        req.session.user = user; // Save user session
        res.redirect("/");
    } catch (err) {
        console.error("Login Error:", err);
        res.status(500).send("Error logging in. Please try again.");
    }
});



app.get("/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/"));
});


app.listen(3001, () => {
    console.log("Server is running on http://localhost:3001");
});